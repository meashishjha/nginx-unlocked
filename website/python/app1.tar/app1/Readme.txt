python -m venv .venv

. .venv/bin/activate

pip install "fastapi[standard]"


fastapi dev --host 127.0.0.1 --port 8100 main.py